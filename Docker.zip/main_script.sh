#!/bin/bash
# apt update

apt install -y openvpn easy-rsa nano ufw

mkdir -p /app/files/ca