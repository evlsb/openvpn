#!/bin/bash

cd /root/easy-rsa/
rm vars.example
./easyrsa init-pki